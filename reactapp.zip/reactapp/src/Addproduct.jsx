import React, { useState } from 'react';
import axios from 'axios'; // Import Axios for making HTTP requests
import './Addproduct.css'; 

const Addproduct = () => {
    // State variables to store form data
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [price, setPrice] = useState('');
    const [specification, setspecification] = useState('');
    const [quantity, setQuantity] = useState('');

    // Function to handle form submission
    const handleSubmit = async (e) => {
        e.preventDefault();

        try {
            // Send POST request to Django backend
            const response = await axios.post('http://localhost:8000/api/add-product/', {
                name,
                description,
                specification,
                quantity,
                price
            });

            console.log('Product added successfully:', response.data);
            // Optionally, redirect to another page or show a success message
        } catch (error) {
            console.error('Error adding product:', error);
            // Handle errors, show error message to user, etc.
        }
    };

    return (
        <div>
            <h2>Add Product</h2>
            <form onSubmit={handleSubmit}>
                <label>
                    Name:
                    <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
                </label>
                <br />
                <label>
                    Description:
                    <input type="text" value={description} onChange={(e) => setDescription(e.target.value)} />
                </label>
                <br />
                <label>
                    Specification:
                    <input type="text" value={specification} onChange={(e) => setspecification(e.target.value)} />
                </label>
                <br />
                <label>
                    Price:
                    <input type="number" value={price} onChange={(e) => setPrice(e.target.value)} />
                </label>
                <br />
                <label>
                    Stock Quantity:
                    <input type="number" value={quantity} onChange={(e) => setQuantity(e.target.value)} />
                </label>
                <br />
                <button type="submit">Add Product</button>
            </form>
        </div>
    );
};

export default Addproduct;


