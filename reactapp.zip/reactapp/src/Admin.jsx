import React from 'react';
import {   Link } from 'react-router-dom';


function Admin() {
  return (
   
      <div className="app-container">
        <nav className="sidenav">
          <ul>
            <li>
              <Link to="add-product/">Add product</Link>

            </li>
            <li>
              <Link to="/products">Display Product</Link>
              
            </li>
          </ul>
        </nav>
        <div className="main-content">

        </div>
      </div>
   
  );
}

export default Admin;
